﻿using UnityEngine;

public class TowerShoot : MonoBehaviour
{
    [SerializeField] private TowerData data;
    public TowerData Data { get => data; }
    [SerializeField] private ObjectPooler pooler;
       public int currentDame;
      public float currentSpeed;
      public float sizeBullet;
   private int currentlevel =1;
    private int maxLevel = 2;



    private TowerTarget target;

    private void Awake()
    {
        target = GetComponent<TowerTarget>();
        sizeBullet = data.BulletSize;
        currentDame = data.Damagelv1;
        currentSpeed = data.Speedlv1;
    }

    

    public virtual void Shoot()
    {
        if(target.enemiesInRange.Count >0)
        {
            GameObject bullet = pooler.GetPoolObj();
            bullet.transform.position = transform.position;
            bullet.SetActive(true);
            Bullet bulletScript = bullet.GetComponent<Bullet>();
            if (bulletScript != null)
            {
                bulletScript.SetTarget(target.enemiesInRange[0].transform);
            }
           
         
        }
    }
    public void CheckLevelData(int dataDamage, float dataSpeed)
    {
        currentDame = dataDamage;
        currentSpeed = dataSpeed;

    }

    public bool TryUpgrade ()
    {
        if (currentlevel >= maxLevel || GameManager.Instance.Gold < data.UpgradeCost)
        {
            return false;
        }
        currentlevel++;
        CheckLevelData(data.Damagelv2, data.Speedlv2);
        GameManager.Instance.SpendGold(data.UpgradeCost);
        return true;
    }

  
}
