using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
   public void StartNewGame()
    {
        SceneManager.LoadScene("Game");
    }

    public void QuitTheGame()
    {
        Application.Quit();
    }
}
